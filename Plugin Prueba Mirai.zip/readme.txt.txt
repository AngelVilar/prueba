Plugin de prueba para Mirai
Autor: Ángel Vilar Hernández
Versión: 1.0
Fecha: 27/04/2021